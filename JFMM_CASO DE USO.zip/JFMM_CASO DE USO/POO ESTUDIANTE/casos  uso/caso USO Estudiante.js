import { Estudiante} from "../entidad/Estudiante.js";

export class CasoUsoEstuadiante {

  constructor(repositorioEstudiante) {
    this.repositorioEstudiante= repositorioEstudiante;
  }

  addEstudiante(data) {

    if (!this.existeEstudiante(data.cedula)) {

      const estudiante = new Estudiante(
        data.numeroMatricula,
        data.nombre,
        data.genero,
        data.direccion
      );

      this.repositorioestudiante.addEstudiante(estudiante);

    } else {
      alert('Estudiante')
    }

  }

  existeESTUDIANTE(numeroMatricula) {
    const estudiante = this.repositorioestudiante.buscarestudiante(numeroMatricula)
    return estudiante ? true : false;
  }

}
