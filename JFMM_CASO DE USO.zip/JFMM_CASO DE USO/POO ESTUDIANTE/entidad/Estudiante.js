class Estudiante{
  constructor(cedula, nombre, apellido, genero) {
    this.numeroMatricula = numeroMatricula ;
    this.nombre = nombre;
    this.apellido = apellido;
    this.genero = genero;
  }
}


