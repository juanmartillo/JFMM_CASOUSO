export class RepositorioEstudiante {
  constructor() {
    this.Estudiante = []
  }

  addEstudiante(Estudiante) {
    this.Estudiante.push(estudiante)
  }

  buscarEstudiante(numeroMatricula) {
    return this.Estudiante.filter((item) => item.numeroMatricula=== numeroMatricula).shift()
  }

}
